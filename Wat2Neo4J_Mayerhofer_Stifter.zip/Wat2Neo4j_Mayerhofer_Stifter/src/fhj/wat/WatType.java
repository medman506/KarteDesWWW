package fhj.wat;

public abstract class WatType {
	public final static String gWatTypes[] = {"warcinfo", "request", "response", "metadata"};
	public final static int gWatTypeInfoIdx = 0;
	public final static int gWatTypeRequestIdx = 1;
	public final static int gWatTypeResponseIdx = 2;
	public final static int gWatTypeMetaIdx = 3;
	
	private final String myType;
	private final String myDate;
	private final String myId;
	private final String myFileName;
	
	protected WatType(String type, String date, String id, String fileName){
		if((null == type) || (null == date) || (null == id) || (null == fileName)){
			throw new RuntimeException("null String in Constructor of WatType");
		}
				
		if(isWatTypeValid(type)){
			myType = type;
		} else {
			throw new RuntimeException("Invalide Type");
		}
		
		myDate = date;
		myId = id;
		myFileName = fileName;
	}
	
	public static boolean isWatTypeValid(String typeName){
		for(String type : gWatTypes){
			if(0==typeName.compareTo(type)){
				return true; 
			}
		}
		return false;
	}

	public String getType() {
		return myType;
	}

	public String getDate() {
		return myDate;
	}

	public String getId() {
		return myId;
	}

	public String getFileName() {
		return myFileName;
	}
}
