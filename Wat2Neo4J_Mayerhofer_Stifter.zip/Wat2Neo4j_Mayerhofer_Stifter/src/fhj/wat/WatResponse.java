package fhj.wat;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import fhj.Logger;

public class WatResponse extends WatMessage implements Iterable<URL>{
	private final WatRequest myRequest;
	private final List<URL> myLinks = new ArrayList<URL>();
	private final Logger log = new Logger();
	
	
	public WatResponse(
			String date, 
			String id,
			String fileName,
			WarcInfo wInfo, 
			WatRequest request,
			String uri,
			String ip,
			String[] links) throws URISyntaxException, UnknownHostException, MalformedURLException {
		super(
			WatType.gWatTypes[WatType.gWatTypeResponseIdx],
			date,
			id,
			fileName,
			wInfo,
			uri,
			ip
		);
		
		if( (null == request) ){
			throw new RuntimeException("Error: null-Strings in WatResponse Constructor");
		}
		
		myRequest = request;
		myRequest.setResponse(this);
		initLinks(links);
	}
	
	private void initLinks(String[] links) throws URISyntaxException{
		
		for(final String link : links){
			log.log("Link: " + link);
			
			//if((link.length()>= 4) && (0==link.substring(0, 4).compareTo("http"))){
				
			URI rawUri = null;
			try{
				rawUri = new URI(link);
			} catch(URISyntaxException exc){
				log.print("Invalid Url: " + link);
				break;
			}
			
			if(rawUri.isOpaque()){
				break;
			} else if(!rawUri.isAbsolute()){
				break;
			}

			final URI normUri = URI.create( rawUri.normalize().toASCIIString() );

			try{
				URL url = normUri.toURL();
				log.log("Link added: " + url.toString());
				myLinks.add(url);
			} catch(MalformedURLException exc){
				log.print("Invalid Url: " + normUri.toString());
			}
		//}
		}
	}

	public WatRequest getRequest() {
		return myRequest;
	}

	@Override
	public Iterator<URL> iterator() {
		return myLinks.iterator();
	}
	
	public String[] getLinkedHosts(){
		ArrayList<String> retval = new ArrayList<String>();
		return this.getLinkedHosts(retval);
	}
	
	public String[] getLinkedHostsUnique(){
		HashSet<String> retval = new HashSet<String>();
		return this.getLinkedHosts(retval);	
	}
	
	private String[] getLinkedHosts(Collection<String> retval){
		
		for(URL url : this){
			String host = url.getHost();
			if(null!=host){
				retval.add(host);
			}
		}
		return retval.toArray(new String[0]);
	}
	
	public String[] getLinks(){
		ArrayList<String> retval = new ArrayList<String>();
		return this.getLinks(retval);
	}
	
	public String[] getLinksUnique(){
		HashSet<String> retval = new HashSet<String>();
		return this.getLinks(retval);	
	}
	
	private String[] getLinks(Collection<String> retval){
		
		for(URL url : this){
			try {
				retval.add(url.toURI().toASCIIString());
			} catch (URISyntaxException e) {
				log.print("Invalid uri from url: " + url.toString());
			}
		}
		return retval.toArray(new String[0]);
	}
}
