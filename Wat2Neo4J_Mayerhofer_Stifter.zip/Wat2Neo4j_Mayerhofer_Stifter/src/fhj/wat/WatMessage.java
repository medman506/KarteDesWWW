package fhj.wat;

import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;

public abstract class WatMessage extends WatType {
	private final WarcInfo myWinfo;
	private final URI myUri;
	private final InetAddress myIpAddress;
	
	public WatMessage(
			String watTypeName,
			String date, 
			String id,
			String fileName,
			WarcInfo wInfo, 
			String uri,
			String ip) throws URISyntaxException, UnknownHostException {
		super(
			watTypeName,
			date,
			id,
			fileName
		);
	
		if( (null == wInfo) || (null == uri) || (null == ip) ){
			throw new RuntimeException("Error: null-Strings in WatResponse Constructor");
		}
		
		myWinfo = wInfo;
		URI rawUri = new URI(uri);
		if(rawUri.isOpaque()){
			throw new URISyntaxException(uri, "Uri is opaque");
		} else if(!rawUri.isAbsolute()){
			throw new URISyntaxException(uri, "Uri is not absolute");
		}
		myUri = URI.create( rawUri.normalize().toASCIIString() );
		
		String addr[] = ip.split("\\.");
		byte[] bAddr = new byte[4];
		bAddr[0] = Integer.valueOf(addr[0]).byteValue();
		bAddr[1] = Integer.valueOf(addr[1]).byteValue();
		bAddr[2] = Integer.valueOf(addr[2]).byteValue();
		bAddr[3] = Integer.valueOf(addr[3]).byteValue();
		myIpAddress = InetAddress.getByAddress(bAddr);
	}

	public WarcInfo getWinfo() {
		return myWinfo;
	}

	public URI getUri() {
		return myUri;
	}

	public InetAddress getIpAddress() {
		return myIpAddress;
	}
}
