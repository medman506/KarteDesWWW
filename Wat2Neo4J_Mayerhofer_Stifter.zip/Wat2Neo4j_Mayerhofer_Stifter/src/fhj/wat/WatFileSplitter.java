package fhj.wat;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;

public class WatFileSplitter implements Closeable, AutoCloseable{
	private BufferedReader myReader;
	private FileReader myFileReader;
	
	public WatFileSplitter(String fullFileName) throws FileNotFoundException{
		myFileReader = new FileReader(fullFileName);
		myReader = new BufferedReader(myFileReader);
	}
	
	private BufferedReader getReader(){
		return myReader;
	}
	
	private FileReader getFileReader(){
		return myFileReader;
	}
	
	public String getJsonObjectFromWat() throws IOException{
		String line;
		
		try(StringWriter writer = new StringWriter()){
			while( null != (line = this.getReader().readLine()) ){
				if(!line.isEmpty()){
					if(line.substring(0, 1).compareTo("{")==0){
						return line;
					}
				}
			}
			
			// Input is empty, but no Json Object was completed
			return null;
		}
	}
	
	public void close() throws IOException{
		if(null!=this.getReader()){
			this.getReader().close();
		} 
		
		if(null!=this.getFileReader()){
			this.getFileReader().close();
		}
	}
}
