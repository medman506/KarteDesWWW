package fhj.wat;

public class WarcInfo extends WatType {
	
	private final String myWFilename;
	private final String myHostname;
	
	public WarcInfo(String date, String id, String filename, String wFilename, String hostname){
		super(
			WatType.gWatTypes[WatType.gWatTypeInfoIdx],
			date,
			id,
			filename
		);
		
		myWFilename = wFilename;
		myHostname = hostname;
	}

	public String getWFilename() {
		return myWFilename;
	}

	public String getHostname() {
		return myHostname;
	}
}
