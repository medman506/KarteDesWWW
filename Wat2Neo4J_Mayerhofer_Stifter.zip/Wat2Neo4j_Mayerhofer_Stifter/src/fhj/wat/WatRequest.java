package fhj.wat;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

public class WatRequest extends WatMessage{
	private WatResponse myResponse;
	
	public WatRequest(String date, String id, String FileName, WarcInfo wInfo, String host, String uri, String ipAddress) throws UnknownHostException, URISyntaxException{
		super(
			WatType.gWatTypes[WatType.gWatTypeRequestIdx],
			date,
			id,
			FileName,
			wInfo,
			uri,
			ipAddress
		);
	}

	public WatResponse getResponse() {
		return myResponse;
	}

	public void setResponse(WatResponse response) {
		if(null == myResponse){
			myResponse = response;
		}
	}
}
