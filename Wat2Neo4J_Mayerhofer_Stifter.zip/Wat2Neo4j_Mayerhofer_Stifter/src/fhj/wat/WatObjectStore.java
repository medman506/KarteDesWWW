package fhj.wat;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class WatObjectStore {
	
	private static final WatObjectStore ourStore = new WatObjectStore();
	private static final Map<String, WatType> myWatObjects = new HashMap<String, WatType>();
	
	public static WatObjectStore newWatObjectStore(){
		return ourStore;
	}
	
	private WatObjectStore() {
		super();
	}

	public Collection<WatType> getWatObjects(){
		return myWatObjects.values();
	}
	
	public WatType getWatObject(String id){
		return myWatObjects.get(id);
	}
	
	public void addWatObject(WatType object){
		String id = object.getId();
		myWatObjects.put(id, object);
	}
	
	public WatType removeWatObject(String id){
		return myWatObjects.remove(id);
	}
}
