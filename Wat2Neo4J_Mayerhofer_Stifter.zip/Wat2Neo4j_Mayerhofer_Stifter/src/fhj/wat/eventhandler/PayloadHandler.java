package fhj.wat.eventhandler;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

public class PayloadHandler extends WatEventHandlerImpl implements WatEventHandler {

	public PayloadHandler(WatEventHandlerImpl impl) {
		super(impl);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		switch(event){
			case KEY_NAME:
				if(0==gContainer.compareTo(parser.getString())){
					WatEventHandler newHandler = new ContainerHandler(this);
					newHandler.handle(parser);
					return false;
				}
				return true;
	
			default:
				return true;
		}
	}
}