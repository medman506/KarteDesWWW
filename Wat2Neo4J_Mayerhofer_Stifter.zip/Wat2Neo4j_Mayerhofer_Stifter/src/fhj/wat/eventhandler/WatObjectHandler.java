package fhj.wat.eventhandler;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.Logger;
import fhj.wat.WatObjectStore;

public class WatObjectHandler extends WatEventHandlerImpl implements WatEventHandler {
	private Logger log = new Logger();
	
	public WatObjectHandler(WatEventHandlerImpl handler) {
		super(handler);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		switch(event){
		case KEY_NAME:
			if(0==gEnvelope.compareTo(parser.getString())){
				EnvelopeHandler newHandler = new EnvelopeHandler(this);
				log.log("EnvelopeFound!");
				newHandler.handle(parser);
			}
			return true;
			
		case END_OBJECT:
			return false;
			
		default:
			return true;
		}
	}
	
	public WatObjectStore getResult(){
		return this.getWatObjectStore();
	}
}
