package fhj.wat.eventhandler;

public class WatEventHandlerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8503152259663113975L;

	@Override
	public String getMessage() {
		return "Wat Object Incomplete!";
	}
	
	
}
