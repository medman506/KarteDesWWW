package fhj.wat.eventhandler;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.Logger;

public class ContainerHandler extends WatEventHandlerImpl implements WatEventHandler {
	private boolean myFilenameHappened = false;
	private Logger log = new Logger();
	
	
	public ContainerHandler(WatEventHandlerImpl impl) {
		super(impl);
	}
	
	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException {
		switch(event){
		case KEY_NAME:
			if(0==gFileName.compareTo(parser.getString())){
				log.log("Container Ends!");
				myFilenameHappened = true;
			}
			return true;
			
		case END_OBJECT:
			if(myFilenameHappened){
				return false;
			}
			return true;

		default:
			return true;
		}
	}
}
