package fhj.wat.eventhandler;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.wat.WatType;

public class WatTypeHandler extends WatEventHandlerImpl implements WatEventHandler {
	
	public WatTypeHandler(WatEventHandlerImpl impl) {
		super(impl);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		
		switch(event){
			case VALUE_STRING:
				String type = parser.getString();
				
				if(0 == type.compareTo( WatType.gWatTypes[WatType.gWatTypeInfoIdx] )){
					WatEventHandler handler = new WarcInfoHandler(this);
					handler.handle(parser);
					return false;
				} else if (0 == type.compareTo( WatType.gWatTypes[WatType.gWatTypeRequestIdx] )){
					WatEventHandler handler = new WatRequestHandler(this);
					handler.handle(parser);
					return false;
				} else if (0 == type.compareTo( WatType.gWatTypes[WatType.gWatTypeResponseIdx] )){
					WatEventHandler handler = new WatResponseHandler(this);
					handler.handle(parser);
					return false;
				}
				return false;
				
		default:
			break;
				
		}
		return false;
	}

}
