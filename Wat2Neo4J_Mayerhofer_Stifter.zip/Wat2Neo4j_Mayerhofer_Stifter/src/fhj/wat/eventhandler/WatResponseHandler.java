package fhj.wat.eventhandler;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import fhj.Logger;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.wat.WarcInfo;
import fhj.wat.WatObjectStore;
import fhj.wat.WatRequest;
import fhj.wat.WatResponse;

public class WatResponseHandler extends WatEventHandlerImpl implements WatEventHandler {
	private String myFilename="";
	private String myDate=""; 
	private String myId="";
	private String myWarcInfo="";
	private String myWatRequest="";
	private String myUri="";
	private String myIp="";
	private Logger log = new Logger();
	private WatLinkHandler myWatLinkHandler = new WatLinkHandler(this);
	
	public WatResponseHandler(WatEventHandlerImpl impl) {
		super(impl);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		log.log("Response Event: " + event);
		
		switch(event){	
			case KEY_NAME:
				String keyName = parser.getString();
				switch(keyName){
					case gFileName:
						this.setFilename(null);
						return true;
						
					case gWarcDate:
						this.setDate(null);
						return true;
						
					case gWarcRecordId:
						this.setId(null);
						return true;
						
					case gWarcInfoid:
						this.setWarcInfo(null);
						return true;
						
					case gWarcRef:
						this.setWatRequest(null);
						return true;
						
					case gWarcUri:
						this.setUri(null);
						return true;
						
					case gWarcIp:
						this.setIp(null);
						return true;
						
					case gLinks:
						log.log("Links found!");
						WatLinkHandler handler = this.getWatLinkHandler();
						handler.getLinks().clear();
						handler.handle(parser);
						return true;			
				}
				return true;
			
			case VALUE_STRING:
				return this.setValue(parser);
				
			default:
				return true;
		}
	}
	
	private void createWatResponse() throws UnknownHostException, URISyntaxException, MalformedURLException{
		
		final WatObjectStore store = this.getWatObjectStore();
		final WarcInfo info = (WarcInfo) store.getWatObject(this.getWarcInfo());
		
		if(null == info){
			throw new RuntimeException("Error: No winfo: " + info + " found!");
		}
		
		final WatRequest request = (WatRequest) store.getWatObject(this.getWatRequest());
		
		if(null == request){
			throw new RuntimeException("Error: No request: " + request + " found!");
		}
		
		// WatResponse
		// public WatResponse(
		//		String date, 
		//		String id,
		//		String fileName,
		//		WarcInfo wInfo, 
		//		WatRequest request,
		//		String uri,
		//		String ip,
		//		String[] links)
		
		log.log("New WatResponse:");
		log.log("Id: " + this.getId());
		log.log("Date: " + this.getDate());
		log.log("FileName: " + this.getFilename());
		log.log("Winfo: " + info);
		log.log("Request: " + request);
		log.log("Uri: " + this.getUri().toString());
		log.log("IP: " + this.getIp());
		log.log("Links: " + this.getWatLinkHandler().getLinks());
		
		// find request and info object
		final WatResponse response =
		new WatResponse(	this.getDate(),
							this.getId(), 
							this.getFilename(), 
							info, 
							request, 
							this.getUri(), 
							this.getIp(),
							this.getWatLinkHandler().getLinks().toArray(new String[0]));
		
		this.getWatObjectStore().addWatObject(response);
	}
	
	private boolean setValue(JsonParser parser) throws WatEventHandlerException{
		
		// Filename is the last Element in an WarcInfo
		if(null == this.getFilename()){
			this.setFilename(parser.getString());
			try{
				this.createWatResponse();
			}catch(Exception exc){
				log.log(exc.getMessage());
				for(StackTraceElement el : exc.getStackTrace()){
					log.log(el.toString());
				}
				throw new WatEventHandlerException();
			}
			return false;
		} 
		
		if (null == this.getDate()){
			this.setDate(parser.getString());
			return true;
		} 
		
		if (null == this.getId()){
			this.setId(parser.getString());
			return true;
		}
		
		if (null == this.getWarcInfo()){
			this.setWarcInfo(parser.getString());
			return true;
		}
		
		if (null == this.getWatRequest()){
			this.setWatRequest(parser.getString());
			return true;
		}
		
		if (null == this.getUri()){
			this.setUri(parser.getString());
			return true;
		}
		
		if (null == this.getIp()){
			this.setIp(parser.getString());
			return true;
		}
		
		return true;
	}

	private void setFilename(String filename) {
		myFilename = filename;
	}

	private void setDate(String date) {
		myDate = date;
	}

	private void setId(String id) {
		myId = id;
	}

	private void setWarcInfo(String warcInfo) {
		myWarcInfo = warcInfo;
	}

	private void setWatRequest(String watRequest) {
		myWatRequest = watRequest;
	}

	private void setUri(String uri) {
		myUri = uri;
	}

	private void setIp(String ip) {
		myIp = ip;
	}

	public String getFilename() {
		return myFilename;
	}

	public String getDate() {
		return myDate;
	}

	public String getId() {
		return myId;
	}

	public String getWarcInfo() {
		return myWarcInfo;
	}

	public String getWatRequest() {
		return myWatRequest;
	}

	public String getUri() {
		return myUri;
	}

	public String getIp() {
		return myIp;
	}

	private WatLinkHandler getWatLinkHandler() {
		return myWatLinkHandler;
	}
}
