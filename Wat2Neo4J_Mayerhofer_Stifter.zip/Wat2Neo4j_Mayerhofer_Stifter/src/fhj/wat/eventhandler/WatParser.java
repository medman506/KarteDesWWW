package fhj.wat.eventhandler;

import java.io.StringReader;
import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.Json;
import javax.json.stream.JsonParser;

import fhj.wat.WatObjectStore;

public class WatParser{
	private final WatObjectHandler myHandler = new WatObjectHandler(null);
	
	public void parse(String watObject) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		try (StringReader br = new StringReader(watObject)) {
		    try(JsonParser jp = Json.createParser(br)){
		    	this.getHandler().handle(jp);
		    } 
		}
	}

	private WatObjectHandler getHandler() {
		return myHandler;
	}
	
	public WatObjectStore getResult(){
		return myHandler.getResult();
	}
}
