package fhj.wat.eventhandler;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.Logger;

public class EnvelopeHandler extends WatEventHandlerImpl implements WatEventHandler {
	private Logger log = new Logger();
	
	public EnvelopeHandler(WatEventHandlerImpl impl) {
		super(impl);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		switch(event){
			case KEY_NAME:
				String keyName = parser.getString();
				WatEventHandler newHandler = null;
				
				switch(keyName){
					case gPayloadMeta:
						log.log("Payload found");
						newHandler = new PayloadHandler(this);
						newHandler.handle(parser);
						return false;
						
					case gWarcType:
						log.log("Warc-Type found");
						newHandler = new WatTypeHandler(this);
						newHandler.handle(parser);
						return false;
				}
				return true;
				
			default:
				return true;
		}
	}
}
