package fhj.wat.eventhandler;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.wat.WatObjectStore;

public abstract class WatEventHandlerImpl implements WatEventHandler{
	
	private final WatObjectStore myStore;
	
	public WatEventHandlerImpl(WatEventHandlerImpl impl) {
		super();
		if(null == impl){
			myStore = WatObjectStore.newWatObjectStore();
		} else {
			myStore = impl.getWatObjectStore();
		}
	}

	protected abstract boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException, UnknownHostException, URISyntaxException;
	
	@Override
	public void handle(JsonParser parser) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		while(parser.hasNext()){
    		if( !handleEvent(parser, parser.next()) ){
    			return;
    		}
    	}
		throw new WatEventHandlerException();
	}

	protected WatObjectStore getWatObjectStore() {
		return myStore;
	}
}
