package fhj.wat.eventhandler;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.stream.JsonParser;

public interface WatEventHandler {
	public static final String gEnvelope = "Envelope";
	public static final String gPayloadMeta = "Payload-Metadata";
	public static final String gContainer = "Container";
	public static final String gFileName = "Filename"; // Filename specified in each wat object
	public static final String gLinks = "Links"; // followed by an array of links
	public static final String gWarcType = "WARC-Type"; // type of the wat object
	public static final String gWFileName = "WARC-Filename"; // name of file specified in WARC Info
	public static final String gHostName = "hostname";
	public static final String gWarcDate = "WARC-Date";
	public static final String gWarcRecordId = "WARC-Record-ID"; // unique ID of each wat object
	public static final String gWarcTargetUri = "WARC-Target-URI"; // URI of request/response
	public static final String gWarcInfoid = "WARC-Warcinfo-ID"; // id of the referenced WARC-Info object 
	public static final String gWarcRef = "WARC-Concurrent-To"; // metadata references response, response references request 
	public static final String gWarcUri = "WARC-Target-URI"; // uri which responded
	public static final String gWarcIp = "WARC-IP-Address"; // IP-Address
	public static final String gHost = "Host"; // Host
	public static final String gUrl = "url"; // Url
	
	void handle(JsonParser parser) throws WatEventHandlerException, UnknownHostException, URISyntaxException;
}
