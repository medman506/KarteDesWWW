package fhj.wat.eventhandler;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.Logger;
import fhj.wat.WarcInfo;
import fhj.wat.WatObjectStore;
import fhj.wat.WatRequest;

public class WatRequestHandler extends WatEventHandlerImpl implements WatEventHandler {
	private String myFilename="";
	private String myDate="";
	private String myId="";
	private String myUri="";
	private String myIp="";
	private String myWInfo="";
	private String myHost="";
	private Logger log = new Logger();
	
	public WatRequestHandler(WatEventHandlerImpl impl) {
		super(impl);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException, UnknownHostException, URISyntaxException {
		switch(event){
			case KEY_NAME:
				String keyName = parser.getString();
				switch(keyName){
					case gFileName:
						this.setFilename(null);
						return true;
						
					case gWarcDate:
						this.setDate(null);
						return true;
						
					case gWarcRecordId:
						this.setId(null);
						return true;
					
					case gWarcTargetUri:
						this.setUri(null);
						return true;
						
					case gWarcIp:
						this.setIp(null);
						return true;
						
					case gWarcInfoid:
						this.setWInfo(null);
						return true;
						
					case gHost:
						this.setHost(null);
						return true;
				}
				return true;
			
			case VALUE_STRING:
				return this.setValue(parser);
				
			default:
				return true;
		}
	}
	
	private void createRequest() throws UnknownHostException, URISyntaxException{
		final WatObjectStore store = this.getWatObjectStore();
		WarcInfo wInfo = (WarcInfo) store.getWatObject(this.getWInfo());

		if(null == wInfo){
			throw new RuntimeException("Error: No winfo: " + wInfo + " found!");
		}
		
		//WatRequest(String date, String id, String FileName, WarcInfo wInfo, String host, String uri, String ipAddress)
		log.log("New WatRequest:");
		log.log("Id: " + this.getId());
		log.log("Date: " + this.getDate());
		log.log("FileName: " + this.getFilename());
		log.log("Winfo: " + wInfo);
		log.log("Host: " + this.getHost());
		log.log("Uri: " + this.getUri().toString());
		log.log("IP: " + this.getIp());
		final WatRequest request = new WatRequest(this.getDate(), this.getId(), this.getFilename(), wInfo, this.getHost(), this.getUri(), this.getIp());
		this.getWatObjectStore().addWatObject(request);
	}
	
	private boolean setValue(JsonParser parser) throws UnknownHostException, URISyntaxException{
		
		final String value = parser.getString();
		
		// Filename is the last Element in an WarcInfo
		if(null == this.getFilename()){
			this.setFilename(value);
			this.createRequest();
			return false;
		} 
		
		if(null == this.getDate()){
			this.setDate(value);
			return true;
		} 
		
		if(null == this.getId()){
			this.setId(value);
			return true;
		}
		
		if(null == this.getWInfo()){
			this.setWInfo(value);
			return true;
		}
		
		if(null == this.getUri()){
			this.setUri(value);
		}
		
		if(null == this.getHost()){
			this.setHost(value);
		}
		
		if(null==this.getIp()){
			this.setIp(value);
		}
		
		return true;
	}

	public String getFilename() {
		return myFilename;
	}

	private void setFilename(String filename) {
		myFilename = filename;
	}

	public String getDate() {
		return myDate;
	}

	private void setDate(String date) {
		myDate = date;
	}

	public String getId() {
		return myId;
	}

	private void setId(String id) {
		myId = id;
	}
	
	public String getUri(){
		return myUri;
	}
	
	private void setUri(String uri){
		myUri = uri;
	}
	
	public String getIp(){
		return myIp;
	}
	
	private void setIp(String ip){
		myIp = ip;
	}
	
	public String getWInfo() {
		return myWInfo;
	}

	private void setWInfo(String wInfo) {
		myWInfo = wInfo;
	}
	
	public String getHost(){
		return myHost;
	}
	
	private void setHost(String host){
		myHost = host;
	}
}
