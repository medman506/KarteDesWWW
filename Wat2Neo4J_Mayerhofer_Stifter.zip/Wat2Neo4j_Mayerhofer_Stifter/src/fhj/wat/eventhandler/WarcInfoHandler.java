package fhj.wat.eventhandler;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.wat.WarcInfo;

public class WarcInfoHandler extends WatEventHandlerImpl implements WatEventHandler {
	private String myFilename="";
	private String myHostname="";
	private String myWFilename="";
	private String myDate="";
	private String myId="";
	
	public WarcInfoHandler(WatEventHandlerImpl impl) {
		super(impl);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException {
		switch(event){
			case KEY_NAME:
				String keyName = parser.getString();
				switch(keyName){
					case gWFileName:
						this.setWFilename(null);
						return true;
						
					case gHostName:
						this.setHostname(null);
						return true;
						
					case gFileName:
						this.setFilename(null);
						return true;
						
					case gWarcDate:
						this.setDate(null);
						return true;
						
					case gWarcRecordId:
						this.setId(null);
				}
				return true;
			
			case VALUE_STRING:
				return this.setValue(parser);
				
			default:
				return true;
		}
	}
	
	private void createWarcInfo(){
		final WarcInfo info = new WarcInfo(this.getDate(), this.getId(), this.getFilename(), this.getWFilename(), this.getHostname());
		this.getWatObjectStore().addWatObject(info);
	}
	
	private boolean setValue(JsonParser parser){
		
		// Filename is the last Element in an WarcInfo
		if(null == this.getFilename()){
			this.setFilename(parser.getString());
			this.createWarcInfo();
			return false;
		}
		
		if (null == this.getHostname()){
			this.setHostname(parser.getString());
			return true;
		} 
		
		if (null == this.getWFilename()){
			this.setWFilename(parser.getString());
			return true;
		}
		
		if (null == this.getDate()){
			this.setDate(parser.getString());
			return true;
		}
		
		if (null == this.getId()){
			this.setId(parser.getString());
			return true;
		}
		
		return true;
	}

	public String getFilename() {
		return myFilename;
	}

	private void setFilename(String filename) {
		myFilename = filename;
	}

	public String getHostname() {
		return myHostname;
	}

	private void setHostname(String hostname) {
		myHostname = hostname;
	}

	public String getWFilename() {
		return myWFilename;
	}

	private void setWFilename(String wFilename) {
		myWFilename = wFilename;
	}

	public String getDate() {
		return myDate;
	}

	private void setDate(String date) {
		myDate = date;
	}

	public String getId() {
		return myId;
	}

	private void setId(String id) {
		myId = id;
	}
}
