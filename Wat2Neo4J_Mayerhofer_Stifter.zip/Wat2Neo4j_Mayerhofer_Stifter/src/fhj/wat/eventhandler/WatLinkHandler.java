package fhj.wat.eventhandler;

import java.util.ArrayList;
import java.util.List;

import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

import fhj.Logger;

public class WatLinkHandler extends WatEventHandlerImpl implements WatEventHandler {
	private List<String> myLinks= new ArrayList<String>();
	private boolean myArrayStarted=false;
	private boolean myUrlFound=false;
	Logger log = new Logger();
	
	public WatLinkHandler(WatEventHandlerImpl impl) {
		super(impl);
	}

	public List<String> getLinks(){
		return myLinks;
	}
	
	private boolean isArrayStarted() {
		return myArrayStarted;
	}

	private void startArray(){
		if(isArrayStarted()){
			throw new RuntimeException("WatParse-Error: Array already started!");
		}
		myArrayStarted=true;
	}
	
	private void endArray(){
		if(!isArrayStarted()){
			throw new RuntimeException("WatParse-Error: No Array to end!");
		}
		myArrayStarted=false;
	}

	private boolean isUrlFound() {
		return myUrlFound;
	}

	private void openUrl(){
		if(isUrlFound()){
			throw new RuntimeException("WatParse-Error: Url already open!");
		}
		myUrlFound=true;
	}
	
	private void closeUrl(){
		if(!isUrlFound()){
			throw new RuntimeException("WatParse-Error: Url already closed!");
		}
		myUrlFound=false;
	}
	
	private void addLink(String link){
		this.myLinks.add(link);
	}

	@Override
	protected boolean handleEvent(JsonParser parser, Event event) throws WatEventHandlerException {
		switch(event){
			case START_ARRAY:
				log.log("Start Array!");
				this.startArray();
				return true;
				
			case END_ARRAY:
				log.log("End Array!");
				this.endArray();
				return false;
			
			case KEY_NAME:
				String keyName = parser.getString();
				log.log("Key: " + keyName);
						
				if(0==keyName.compareTo(WatEventHandler.gUrl)){
					this.openUrl();
				}
				return true;
				
			case VALUE_STRING:
				if(this.isUrlFound()){
					this.closeUrl();
					final String url = parser.getString();
					log.log("Url: " + url);
					this.addLink(url);
				}
				return true;
				
			default:
				return true;
		}
	}
}
