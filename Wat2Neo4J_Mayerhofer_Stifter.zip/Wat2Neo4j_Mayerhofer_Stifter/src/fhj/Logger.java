package fhj;

public class Logger {

	public void log(String text){
		//System.out.println(text);
	}
	
	public void print(String text){
		System.out.println(text);
	}
}
