package fhj;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LineReader{
	
	private BufferedReader myReader;
	private FileReader myFileReader;
	private final Logger log = new Logger();

	public LineReader(String fullFileName) throws FileNotFoundException{
		myFileReader = new FileReader(fullFileName);
		myReader = new BufferedReader(myFileReader);
	}

	private BufferedReader getReader(){
		return myReader;
	}

	public String getLine() throws IOException{
		String line;

		while( null != (line = this.getReader().readLine()) ){
			log.log(line);
			return line;
		}
		return null;
	}
}
