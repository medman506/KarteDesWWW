package fhj;

public class StopWatch {

	private long startTime = -1;
	private long stopTime = -1;
	private boolean running = false;

	public StopWatch start() {
		startTime = System.currentTimeMillis();
		running = true;
		return this;
	}

	public StopWatch stop() {
		stopTime = System.currentTimeMillis();
		running = false;
		return this;
	}

	/** returns elapsed time in milliseconds
	 * if the watch has never been started then
	 * return zero
	 */

	public long getElapsedTime() {
		if (startTime == -1) {
			return 0;
		}
		if (running){
			return System.currentTimeMillis() - startTime;
		} else {
			return stopTime-startTime;
		} 
	}
	
	public String getElapsedTimeHours() {
		long time = getElapsedTime();
		final long millis = Math.floorMod(time, 1000);
		time = time - millis;
		time = time/1000l; // Grundeinheit: Sekunden
		final long seconds = Math.floorMod(time, 60);
		time = Math.floorDiv(time, 60); // Grundeinheit: Minuten
		final long minutes = Math.floorMod(time, 60);
		final long hours = Math.floorDiv(time, 60);
		return hours + "h " + minutes + "m " + seconds + "s " + millis + "ms";
	}

	public StopWatch reset() {
		startTime = -1;
		stopTime = -1;
		running = false;
		return this;
	}
}
