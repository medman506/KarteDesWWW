package fhj;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;

import org.neo4j.graphdb.GraphDatabaseService;

import fhj.wat.WatFileSplitter;
import fhj.wat.WatObjectStore;
import fhj.wat.WatType;
import fhj.wat.eventhandler.WatEventHandlerException;
import fhj.wat.eventhandler.WatParser;
import fhj.wat2neo.NeoFactory;
import fhj.wat2neo.Wat2Neo;

class SingleController extends Controller{

	public SingleController(String filePath) throws IOException {
		super(filePath);
	}
	
	protected void run() throws FileNotFoundException, IOException, WatEventHandlerException, URISyntaxException{
		
		WatObjectStore store = parseWatFile(this.getFilePath());
		GraphDatabaseService db = this.loadNeoDB();
		this.objects2Neo(db, store);
	}
}

class MultiController extends Controller{

	public MultiController(String filePath) throws IOException {
		super(filePath);
	}
	
	protected void run() throws IOException, WatEventHandlerException, InterruptedException, URISyntaxException{
		
		StopWatch watch = new StopWatch();
		watch.start();
		
		this.deleteNeoDB();
		final GraphDatabaseService db = this.loadNeoDB();
		
		// read the list of zipped WatFiles
		LineReader reader = new LineReader(this.getFilePath());
		String line = null;
		int counter = 0;
		
		while( null != (line = reader.getLine()) ){
			if(!line.isEmpty()){
				// download, unzip, parse, delete File then add to database
				log.print(watch.getElapsedTimeHours() + ": processing file #" + ++counter + " ...");
				final String zipFile = this.downloadZipWatFile(line);
				final String watFile = this.extractZipWatFile(zipFile);
				final WatObjectStore store = parseWatFile(watFile);
				this.deleteFile(watFile);
				this.objects2Neo(db, store);
				log.print("Finshed watFile " + watFile);
			}
		}
	}
	
}

public abstract class Controller {
	
	private final static String gUrlPrefix = "https://commoncrawl.s3.amazonaws.com/";
			
	private String myFilePath;
	private String myDbPath;
	private String myDbConfigPath;
	protected static Logger log = new Logger();
	
	public Controller(String cfgFilePath) throws IOException {
		super();
		
		LineReader reader = new LineReader(cfgFilePath);
		this.setDbPath(reader.getLine());
		this.setDbConfigPath(reader.getLine());
		this.setFilePath(reader.getLine());
	}

	public static void main(String[] args) throws IOException, WatEventHandlerException, InterruptedException, URISyntaxException {
		
		// args[1] = path to wat file
		if( (args.length < 2) ||((args[0].compareTo("single")!=0) && (args[0].compareTo("multi")!=0) )){
			log.print("Usage: [single|multi] [cfg_file]");
			return;
		}
		
		Controller controller = null;
		if(args[0].compareTo("single")!=0){
			controller = new MultiController(args[1]);
		} else {
			controller = new SingleController(args[1]);
		}
		
		controller.run();
		log.print("Program Wat2Neo4j finished!");
	
		System.exit(0);
	}
	
	abstract protected void run() throws FileNotFoundException, IOException, WatEventHandlerException, InterruptedException, URISyntaxException;
	
	protected boolean deleteNeoDB() throws IOException, InterruptedException{
		log.print("Deleting " + this.getDbPath());
		final String command = "rm -rf " + this.getDbPath();
		final Process proc = Runtime.getRuntime().exec(command);
		log.print(command);
		if(0==proc.waitFor()){
			log.print("... success!");
			return true;
		} else {
			log.print("... failure!");
			return false;
		}
	}
	
	protected GraphDatabaseService loadNeoDB(){
		log.print("Loading neo4j ...");
		final NeoFactory factory = new NeoFactory();
		final GraphDatabaseService graphDb = factory.newNewDB(this.getDbPath(), this.getDbConfigPath());
		log.print("Neo4j loaded!");
		return graphDb;
	}
	
	protected String downloadZipWatFile(String urlPart) throws IOException, InterruptedException{
		final String fileOnDisk = urlPart.substring(urlPart.lastIndexOf("/")+1);
		
		boolean retry=false;
		this.deleteFile(fileOnDisk); // asure there is no name collision
		log.print("Downloading " + urlPart + " ...");
		do{
			retry = false;
			final Process proc = Runtime.getRuntime().exec("wget -q --no-check-certificate " + gUrlPrefix + urlPart);
			if(!proc.waitFor(30, TimeUnit.MINUTES)){
				log.print("Timeout - retry!");
				this.deleteFile(fileOnDisk);
				retry = true;
			};
		} while(retry);
		log.print(urlPart + " downloaded!");
		return fileOnDisk;
	}
	
	protected String extractZipWatFile(String zipWatFilePath) throws IOException, InterruptedException{
		log.print("Gunzip " + zipWatFilePath + " ...");
		final Process proc = Runtime.getRuntime().exec("gunzip " + zipWatFilePath);
		proc.waitFor();
		log.print(zipWatFilePath + " gunzipped!");
		return zipWatFilePath.substring(0, zipWatFilePath.lastIndexOf(".gz"));
	}
	
	protected boolean deleteFile(String filePath) throws IOException, InterruptedException{
		log.print("Deleting " + filePath);
		final Process proc = Runtime.getRuntime().exec("rm " + filePath);
		if(0==proc.waitFor()){
			log.print("... success!");
			return true;
		} else {
			log.print("... failure!");
			return false;
		}
	}
	
	protected WatObjectStore parseWatFile(String watPath) throws FileNotFoundException, IOException, WatEventHandlerException, URISyntaxException{
		// create splitter and parser
		StopWatch watch = new StopWatch();
		watch.start();
		
		log.print("Parsing file " + watPath);
		int counter = 0;
		WatParser parser = new WatParser();

		try(WatFileSplitter splitter = new WatFileSplitter(watPath)){
			String watObject;

			while(null != (watObject = splitter.getJsonObjectFromWat()) ){
				counter++;
				parser.parse(watObject);
			}
		}
	
		final WatObjectStore watStore = parser.getResult();
		log.print("Finished parsing file " + watPath + "!");
		
		///////////////////////////////////////////////
		// print the number of objects
		///////////////////////////////////////////////
		
		int infoCounter=0;
		int requestCounter=0;
		int responseCounter=0;
		
		for(WatType wat : watStore.getWatObjects()){
			if(0==wat.getType().compareTo(WatType.gWatTypes[WatType.gWatTypeInfoIdx])){
				infoCounter++;
			}
			
			if(0==wat.getType().compareTo(WatType.gWatTypes[WatType.gWatTypeRequestIdx])){
				requestCounter++;
			}

			if(0==wat.getType().compareTo(WatType.gWatTypes[WatType.gWatTypeResponseIdx])){
				responseCounter++;
			}
		}
		watch.stop();
		log.print("Objects-Total: " + counter + " Info: " + infoCounter + " Request: " + requestCounter + " Response: " + responseCounter);
		log.print("Time (ms) needed: " + watch.getElapsedTime());
		return watStore;
	}
	
	protected void objects2Neo(GraphDatabaseService graphDb, WatObjectStore watStore){
		//////////////////////////////////////////////////
		// Objects to Neo
		//////////////////////////////////////////////////

		StopWatch watch = new StopWatch();
		watch.start();
		
		log.print("Filling up Neo4J!");
		final Wat2Neo wat2neo = new Wat2Neo(graphDb);
		wat2neo.wat2Neo(watStore);
		watch.stop();
		log.print("Neo4J filled up in " + watch.getElapsedTime() + "ms!");
	}

	/**
	 * @return the filePath
	 */
	protected String getFilePath() {
		return myFilePath;
	}

	/**
	 * @param filePath the filePath to set
	 */
	protected void setFilePath(String filePath) {
		myFilePath = filePath;
	}

	/**
	 * @return the dbPath
	 */
	protected String getDbPath() {
		return myDbPath;
	}

	/**
	 * @param dbPath the dbPath to set
	 */
	protected void setDbPath(String dbPath) {
		myDbPath = dbPath;
	}

	/**
	 * @return the dbConfigPath
	 */
	protected String getDbConfigPath() {
		return myDbConfigPath;
	}

	/**
	 * @param dbConfigPath the dbConfigPath to set
	 */
	protected void setDbConfigPath(String dbConfigPath) {
		myDbConfigPath = dbConfigPath;
	}
}
