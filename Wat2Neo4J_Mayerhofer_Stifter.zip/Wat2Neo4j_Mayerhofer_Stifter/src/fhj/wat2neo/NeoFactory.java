package fhj.wat2neo;

import java.io.File;

import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.factory.GraphDatabaseBuilder;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;

import fhj.Logger;

public class NeoFactory {
	private Logger log = new Logger();

	/**
	 * @param args
	 */
	public GraphDatabaseService newNewDB(String dbPath, String configFilePath) {

		log.log("Preparing Builder");
		final File dbFile = new File(dbPath);
		final GraphDatabaseFactory factory = new GraphDatabaseFactory();
		final GraphDatabaseBuilder dbBuilder = factory.newEmbeddedDatabaseBuilder(dbFile);

		log.log("Reading Configuration ...");
		dbBuilder.loadPropertiesFromFile(configFilePath);

		final GraphDatabaseService graphDb = dbBuilder.newGraphDatabase();

		try{
			log.log("Registering Hook ...");
			registerShutdownHook(graphDb);
		} catch(Exception exc) {
			graphDb.shutdown();
			System.out.println(exc.getMessage());
			System.exit(1);
		}

		log.print("Neo4JDB: " + dbPath + " loaded!");
		return graphDb;
	}
	
	private void registerShutdownHook( GraphDatabaseService graphDb )
	{
		// Registers a shutdown hook for the Neo4j instance so that it
		// shuts down nicely when the VM exits (even if you "Ctrl-C" the
		// running application).
		Runtime.getRuntime().addShutdownHook( new Thread()
		{
			@Override
			public void run()
			{
				log.print("Shutting down neo4j ...");
				graphDb.shutdown();
				log.print("Shutting down successful!");
			}
		} );
	}


}
