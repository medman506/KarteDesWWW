package fhj.wat2neo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.neo4j.graphdb.DynamicLabel;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.Transaction;

import fhj.wat.WarcInfo;
import fhj.wat.WatObjectStore;
import fhj.wat.WatRequest;
import fhj.wat.WatResponse;
import fhj.wat.WatType;

@SuppressWarnings("deprecation")
public class Wat2Neo {
	
	 private enum MyRelationshipTypes implements RelationshipType
	 {
	     HOLDS, PROVIDES
	 }
	 
	private final GraphDatabaseService myGraphDb;
	private final Map<String, Node> myInfos = new HashMap<String, Node>();
	
	public final static String gWarcInfoLabel = "WarcInfo";
	public final static String gWatRequestLabel = "WatRequest";
	public final static String gWatResponseLabel = "WatResponse";
	private final static Label ourWarcInfoLabel = DynamicLabel.label(gWarcInfoLabel);
	private final static Label ourWatRequestLabel = DynamicLabel.label(gWatRequestLabel);
	private final static Label ourWatResponseLabel = DynamicLabel.label(gWatResponseLabel);
	
	public Wat2Neo(GraphDatabaseService graphDb) {
		super();
		myGraphDb = graphDb;
	}
	
	//////////////////////////////////////////////////////////////////////////
	// Add all objects of the WatStore to Neo in a single Transaction
	//////////////////////////////////////////////////////////////////////////
	
	public void wat2Neo(WatObjectStore store){
		
		////////////////////////////////////////////////////////
		// Iterate over all WatObjects,
		// whenever a WatObject is added to the database
		// the WatObject Store is changed, thus the
		// iteration is restarted.
		//
		// The iteration stops when the object store is empty
		////////////////////////////////////////////////////////
		
		final GraphDatabaseService db = this.getGraphDb();
		try( Transaction tx = db.beginTx() ){
			
		
			do{
				Iterator<WatType> iter = store.getWatObjects().iterator();
				
				while(iter.hasNext()){
					WatType watObject = iter.next();
					if(null == watObject){
						throw new RuntimeException("Error - WatObjectStore is not empty, after wat2Neo()!");
					}
					boolean added2db = watObject2Neo(watObject, store);
					if(added2db){ break; }
				}
				
				// check that the WatObjectStore is empty
				if(store.getWatObjects().isEmpty()){
					tx.success(); 
					return;
				}
				
			} while(true);
		}
	}
	
	private GraphDatabaseService getGraphDb() {
		return myGraphDb;
	}
	
	private Map<String, Node> getInfos() {
		return myInfos;
	}
	
	private Node getInfoNode(String id){
		return getInfos().get(id);
	}
	
	private void addInfoNode(String id, Node info){
		this.getInfos().put(id, info);
	}

	private boolean hasInfoNode(String id){
		return getInfos().containsKey(id);
	}
	
	private boolean watObject2Neo(WatType object, WatObjectStore store){
		
		//////////////////////////////////////////////////////////////////////////////////////
		// determine type of the wat object
		// Info and response are added to neo and removed from Store,
		// together with attached info and request objects
		//
		// request objects are ignored - they are added indirectly when responses are added
		//////////////////////////////////////////////////////////////////////////////////////
		
		final String type = object.getType();

		if(0 == type.compareTo(WatType.gWatTypes[WatType.gWatTypeInfoIdx])){
			return warcInfo2Neo( (WarcInfo) object, store );
		} else if(0 == type.compareTo(WatType.gWatTypes[WatType.gWatTypeRequestIdx])){
			return false;
		} else if(0 == type.compareTo(WatType.gWatTypes[WatType.gWatTypeResponseIdx])){
			return watResponse2Neo( (WatResponse) object, store );
		} else {
			throw new RuntimeException("Invalid Wat Type: " + type);
		}
	}
	
	private boolean warcInfo2Neo(WarcInfo info, WatObjectStore store){
		
		if(!this.hasInfoNode(info.getId())){
			final Node infoNode = warcInfo2Node(info);
			this.addInfoNode(info.getId(), infoNode);
			store.removeWatObject( info.getId() );
			return true;
		}
		return false;
	}
	
	private boolean watRequest2Neo(WatRequest request, WatObjectStore store, Node responseNode){
		
		final Node requestNode = watRequest2Node(request);
		final Node infoNode = this.getInfoNode(request.getWinfo().getId());
		infoNode.createRelationshipTo(requestNode, MyRelationshipTypes.HOLDS);
		requestNode.createRelationshipTo(responseNode, MyRelationshipTypes.PROVIDES);
		store.removeWatObject( request.getId() );
		return true;
	}
	
	private boolean watResponse2Neo(WatResponse response, WatObjectStore store){
		
		// auto handling of info and request
		final WarcInfo info = response.getWinfo();
		warcInfo2Neo(info, store); // adds only if not already present in info collection
		
		final Node responseNode = watResponse2Node(response);
		final WatRequest request = response.getRequest();
		watRequest2Neo(request, store, responseNode);
		
		store.removeWatObject(response.getId());
		return true;
	}
	
	private Node watObject2Node(WatType object){
		final GraphDatabaseService db = this.getGraphDb();
		
		// set the common properties of each Node
		final Node node = db.createNode();
		node.setProperty("watid", object.getId());
		node.setProperty("date", object.getDate());
		node.setProperty("filename", object.getFileName());
		return node;
	}
	
	private Node warcInfo2Node(WarcInfo info){
		final Node infoNode = watObject2Node(info);
		infoNode.addLabel(ourWarcInfoLabel);
		infoNode.setProperty("hostname", info.getHostname());
		infoNode.setProperty("warc-filename", info.getWFilename());
		return infoNode;
	}
	
	private Node watRequest2Node(WatRequest request){
		final Node requestNode = watObject2Node(request);
		requestNode.addLabel(ourWatRequestLabel);
		requestNode.setProperty("ip_address", request.getIpAddress().toString().substring(1));
		requestNode.setProperty("uri", request.getUri().toASCIIString());
		requestNode.setProperty("host", request.getUri().getHost());
		
		request.getUri();
		return requestNode;
	}
	
	private Node watResponse2Node(WatResponse response){
		final Node responseNode = watObject2Node(response);
		responseNode.addLabel(ourWatResponseLabel);
		responseNode.setProperty("ip_address", response.getIpAddress().toString().substring(1));
		responseNode.setProperty("uri", response.getUri().toASCIIString());
		responseNode.setProperty("host", response.getUri().getHost());
		responseNode.setProperty("links", response.getLinksUnique());
		responseNode.setProperty("linked_hosts", response.getLinkedHostsUnique());
		return responseNode;
	}
}
