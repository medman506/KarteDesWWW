###########################
# !/bin/bash
###########################

java -Xms1g -Xmx2g -cp bin:lib/*:lib/neo4j/* fhj.Controller single cfg/wat2neo_single.cfg
